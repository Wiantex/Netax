# Netax roadmap (kısa)

- v0.3.3 current — dil çekirdeği + keyword case-fold
- v0.4.0 — `deg` + `giris("…", d=A, t=int)`, `f()` kalkar
- v0.5.0 — Netac + NVM (C)
- v0.6.0 — native `.so`
- v0.7.0 — `.axa` paket
- v1.0.0 — stable
- 1.x+ — self-host
