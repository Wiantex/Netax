class Program:
    def __init__(self, statements): self.statements = statements
    def __repr__(self): return f"Program({self.statements!r})"

class PrintStatement:
    def __init__(self, expression): self.expression = expression
    def __repr__(self): return f"PrintStatement({self.expression!r})"

class InputStatement:
    def __init__(self, prompt, variable, value_type):
        self.prompt, self.variable, self.value_type = prompt, variable, value_type
    def __repr__(self): return f"InputStatement({self.prompt!r}, {self.variable!r}, {self.value_type!r})"

class VariableDeclaration:
    def __init__(self, name, expression): self.name, self.expression = name, expression
    def __repr__(self): return f"VariableDeclaration({self.name!r}, {self.expression!r})"

class AssignmentStatement:
    def __init__(self, name, expression, index=None):
        self.name, self.expression, self.index = name, expression, index
    def __repr__(self): return f"AssignmentStatement({self.name!r}, {self.expression!r}, {self.index!r})"

class IfStatement:
    def __init__(self, condition, body, else_if_branches=None, else_body=None):
        self.condition, self.body = condition, body
        self.else_if_branches = else_if_branches or []
        self.else_body = else_body or []
    def __repr__(self): return f"IfStatement({self.condition!r}, {self.body!r}, {self.else_if_branches!r}, {self.else_body!r})"

class ElseIfBranch:
    def __init__(self, condition, body): self.condition, self.body = condition, body
    def __repr__(self): return f"ElseIfBranch({self.condition!r}, {self.body!r})"

class WhileStatement:
    def __init__(self, condition, body): self.condition, self.body = condition, body
    def __repr__(self): return f"WhileStatement({self.condition!r}, {self.body!r})"

class LoopStatement:
    def __init__(self, mode, count, body): self.mode, self.count, self.body = mode, count, body
    def __repr__(self): return f"LoopStatement({self.mode!r}, {self.count!r}, {self.body!r})"

class DonguStatement:
    def __init__(self, kind, count, body):
        self.kind, self.count, self.body = kind, count, body
    def __repr__(self): return f"DonguStatement({self.kind!r}, {self.count!r}, {self.body!r})"

class BreakStatement:
    def __repr__(self): return "BreakStatement()"

class ContinueStatement:
    def __repr__(self): return "ContinueStatement()"

class FunctionDeclaration:
    def __init__(self, name, params, body): self.name, self.params, self.body = name, params, body
    def __repr__(self): return f"FunctionDeclaration({self.name!r}, {self.params!r}, {self.body!r})"

class FunctionCall:
    def __init__(self, name, arguments): self.name, self.arguments = name, arguments
    def __repr__(self): return f"FunctionCall({self.name!r}, {self.arguments!r})"

class ExpressionStatement:
    def __init__(self, expression): self.expression = expression
    def __repr__(self): return f"ExpressionStatement({self.expression!r})"

class ReturnStatement:
    def __init__(self, expression=None): self.expression = expression
    def __repr__(self): return f"ReturnStatement({self.expression!r})"

class NumberLiteral:
    def __init__(self, value): self.value = value
    def __repr__(self): return f"NumberLiteral({self.value!r})"

class BooleanLiteral:
    def __init__(self, value): self.value = value
    def __repr__(self): return f"BooleanLiteral({self.value!r})"

class StringLiteral:
    def __init__(self, value): self.value = value
    def __repr__(self): return f"StringLiteral({self.value!r})"

class Identifier:
    def __init__(self, name): self.name = name
    def __repr__(self): return f"Identifier({self.name!r})"

class BinaryExpression:
    def __init__(self, left, operator, right): self.left, self.operator, self.right = left, operator, right
    def __repr__(self): return f"BinaryExpression({self.left!r}, {self.operator!r}, {self.right!r})"

class UnaryExpression:
    def __init__(self, operator, operand): self.operator, self.operand = operator, operand
    def __repr__(self): return f"UnaryExpression({self.operator!r}, {self.operand!r})"

class ListLiteral:
    def __init__(self, elements): self.elements = elements
    def __repr__(self): return f"ListLiteral({self.elements!r})"

class IndexExpression:
    def __init__(self, target, index): self.target, self.index = target, index
    def __repr__(self): return f"IndexExpression({self.target!r}, {self.index!r})"

class InputExpression:
    def __init__(self, variable, value_type): self.variable, self.value_type = variable, value_type
    def __repr__(self): return f"InputExpression({self.variable!r}, {self.value_type!r})"
