class NetaxError(Exception):

    def __init__(
        self,
        message,
        line=None,
        column=None,
        error_type="Netax Error",
        code=None
    ):
        self.message = message
        self.line = line
        self.column = column
        self.error_type = error_type
        self.code = code

        super().__init__(
            self.format()
        )

    def format(self):

        location = ""

        if self.line is not None:
            location += f"Satır {self.line}"

        if self.column is not None:
            if location:
                location += ", "

            location += f"Sütun {self.column}"

        if location:
            location = f"{location}: "

        code_text = ""

        if self.code:
            code_text = f"[{self.code}] "

        return (
            f"{self.error_type}: "
            f"{code_text}"
            f"{location}"
            f"{self.message}"
        )


class NetaxSyntaxError(NetaxError):

    def __init__(
        self,
        message,
        line=None,
        column=None,
        code=None
    ):
        super().__init__(
            message,
            line,
            column,
            "Syntax Error",
            code
        )


class NetaxRuntimeError(NetaxError):

    def __init__(
        self,
        message,
        line=None,
        column=None,
        code=None
    ):
        super().__init__(
            message,
            line,
            column,
            "Runtime Error",
            code
        )


class NetaxCompileError(NetaxError):

    def __init__(
        self,
        message,
        line=None,
        column=None,
        code=None
    ):
        super().__init__(
            message,
            line,
            column,
            "Compile Error",
            code
        )
