from errors import NetaxSyntaxError

def norm_ident(text):
    # Keyword bakisi ASCII/Turkce I farketmez: Giris, giris, GIRIS, GİRİS
    out=[]
    for ch in text:
        if ch in ("I","İ","ı","i"):
            out.append("i")
        elif "A"<=ch<="Z":
            out.append(chr(ord(ch)+32))
        else:
            out.append(ch)
    return "".join(out)

class Token:
    def __init__(self, type_, value, line, column): self.type, self.value, self.line, self.column = type_, value, line, column
    @property
    def position(self): return self.column
    def __repr__(self): return f"Token({self.type!r}, {self.value!r}, line={self.line}, column={self.column})"

class Lexer:
    KEYWORDS = {
        "yazdir":"YAZDIR", "giris":"GIRIS", "var":"VAR", "f":"F",
        "eger":"EGER", "degilse":"DEGILSE", "iken":"IKEN",
        "fonksiyon":"FONKSIYON", "don":"DON", "loop":"LOOP",
        "normal":"NORMAL",
        "dogru":"DOGRU", "yanlis":"YANLIS",
        "ve":"VE", "veya":"VEYA", "degil":"DEGIL",
        "dongu":"DONGU", "sonsuz":"SONSUZ", "kir":"KIR", "devam":"DEVAM",
        "liste":"LISTE", "ekle":"EKLE", "sil":"SIL", "uzunluk":"UZUNLUK",
    }
    TWO_CHAR_OPERATORS = {"==":"EQUAL_EQUAL", "!=":"NOT_EQUAL", "<=":"LESS_EQUAL", ">=":"GREATER_EQUAL"}
    ONE_CHAR_OPERATORS = {"=":"EQUAL", "<":"LESS", ">":"GREATER", "+":"PLUS", "-":"MINUS"}
    SYMBOLS = {"(":"LPAREN", ")":"RPAREN", "{":"LBRACE", "}":"RBRACE", "[":"LBRACKET", "]":"RBRACKET", ";":"SEMICOLON", ",":"COMMA"}
    def __init__(self, source): self.source, self.position, self.line, self.column, self.tokens = source, 0, 1, 1, []
    def advance(self):
        if self.position >= len(self.source): return "\0"
        c=self.source[self.position]; self.position+=1
        if c=="\n": self.line+=1; self.column=1
        else: self.column+=1
        return c
    def peek(self): return self.source[self.position] if self.position < len(self.source) else "\0"
    def peek_next(self): return self.source[self.position+1] if self.position+1 < len(self.source) else "\0"
    def peek_at(self,n): return self.source[self.position+n] if self.position+n < len(self.source) else "\0"
    def tokenize(self):
        while self.position < len(self.source):
            c=self.peek()
            if c.isspace(): self.advance(); continue
            if c=='#':
                while self.peek() not in ('\n','\0'): self.advance()
                continue
            line,col=self.line,self.column
            if c.isdigit(): self.tokens.append(self.read_number(line,col)); continue
            if c.isalpha() or c=='_': self.tokens.append(self.read_identifier(line,col)); continue
            if c=='"':
                if self.peek_next()=='"' and self.peek_at(2)=='"':
                    self.tokens.append(self.read_multiline_string(line,col)); continue
                self.tokens.append(self.read_string(line,col)); continue
            two=c+self.peek_next()
            if two in self.TWO_CHAR_OPERATORS:
                self.advance(); self.advance(); self.tokens.append(Token(self.TWO_CHAR_OPERATORS[two],two,line,col)); continue
            if c in self.ONE_CHAR_OPERATORS:
                self.advance(); self.tokens.append(Token(self.ONE_CHAR_OPERATORS[c],c,line,col)); continue
            if c in self.SYMBOLS:
                self.advance(); self.tokens.append(Token(self.SYMBOLS[c],c,line,col)); continue
            if c=='!': raise NetaxSyntaxError("Tek başına '!' kullanılamaz. '!=' kullanmalısın.",line,col,"NAX-E001")
            raise NetaxSyntaxError(f"Bilinmeyen karakter: {c!r}",line,col,"NAX-E002")
        self.tokens.append(Token("EOF",None,self.line,self.column)); return self.tokens
    def read_number(self,line,column):
        start=self.position
        while self.peek().isdigit(): self.advance()
        return Token("NUMBER",int(self.source[start:self.position]),line,column)
    def read_identifier(self,line,column):
        start=self.position
        while self.peek().isalnum() or self.peek()=='_': self.advance()
        value=self.source[start:self.position]
        return Token(self.KEYWORDS.get(norm_ident(value),"IDENTIFIER"),value,line,column)
    def read_escape(self):
        self.advance(); e=self.peek(); m={"n":"\n","t":"\t",'"':'"',"\\":"\\"}
        if e not in m: raise NetaxSyntaxError(f"Bilinmeyen kaçış karakteri: \\{e}",self.line,self.column,"NAX-E003")
        self.advance(); return m[e]
    def read_string(self,line,column):
        self.advance(); chars=[]
        while self.position < len(self.source):
            c=self.peek()
            if c=='"': self.advance(); return Token("STRING","".join(chars),line,column)
            if c=='\\': chars.append(self.read_escape()); continue
            if c=='\n': raise NetaxSyntaxError("String kapatilmamis.",self.line,self.column,"NAX-E004")
            chars.append(self.advance())
        raise NetaxSyntaxError("String kapatilmamis.",line,column,"NAX-E004")
    def read_multiline_string(self,line,column):
        self.advance(); self.advance(); self.advance(); chars=[]
        while self.position < len(self.source):
            if self.peek()=='"' and self.peek_next()=='"' and self.peek_at(2)=='"':
                self.advance(); self.advance(); self.advance()
                return Token("STRING","".join(chars),line,column)
            if self.peek()=='\\': chars.append(self.read_escape()); continue
            chars.append(self.advance())
        raise NetaxSyntaxError("Cok satirli string kapatilmamis.",line,column,"NAX-E004")
