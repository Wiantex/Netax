Python toolchain buraya gelir:

netax.py, lexer.py, parser.py, compiler.py, vm.py, bax.py, opcodes.py, netax_ast.py, errors.py

Kaynaklar hazırsa bu klasöre kopyalanır.
