from opcodes import *
from errors import NetaxRuntimeError

class CallFrame:
    def __init__(self, return_ip, locals_): self.return_ip=return_ip; self.locals=locals_

class NetaxVM:
    def __init__(self): self.stack=[]; self.variables={}; self.constants=[]; self.code=[]; self.ip=0; self.frames=[]; self.current_locals=None
    def load_program(self,constants,code):
        self.constants=constants; self.code=code; self.stack.clear(); self.variables.clear(); self.frames.clear(); self.current_locals=None; self.ip=0
    def runtime_error(self,message,code): raise NetaxRuntimeError(message,code=code)
    def read_u16(self):
        if self.ip+1>=len(self.code): self.runtime_error("Bytecode icinde eksik 16-bit operand.","NAX-R001")
        v=(self.code[self.ip]<<8)|self.code[self.ip+1]; self.ip+=2; return v
    def pop_stack(self):
        if not self.stack: self.runtime_error("Stack underflow.","NAX-R002")
        return self.stack.pop()
    def is_int(self,v): return isinstance(v,int) and not isinstance(v,bool)
    def is_bool(self,v): return isinstance(v,bool)
    def is_list(self,v): return isinstance(v,list)
    def format_value(self,v):
        if v is True: return "dogru"
        if v is False: return "yanlis"
        if v is None: return "bos"
        if isinstance(v,list): return "["+", ".join(str(self.format_value(x)) for x in v)+"]"
        return v
    def require_bool(self,v,code="NAX-R019"):
        if not self.is_bool(v): self.runtime_error("Kosul boolean olmali (dogru/yanlis).",code)
        return v
    def require_list(self,v):
        if not self.is_list(v): self.runtime_error("Liste bekleniyordu.","NAX-R020")
        return v
    def require_index(self,v,n):
        if not self.is_int(v): self.runtime_error("Liste indeksi tam sayi olmali.","NAX-R021")
        if v<0 or v>=n: self.runtime_error(f"Liste indeksi aralik disi: {v}","NAX-R022")
        return v
    def set_local(self,i,v):
        if self.current_locals is None: self.runtime_error("Local degisken fonksiyon disinda kullanildi.","NAX-R011")
        self.current_locals[i]=v
    def get_local(self,i):
        if self.current_locals is None or i not in self.current_locals: self.runtime_error(f"Tanimlanmamis local degisken: {i}","NAX-R012")
        return self.current_locals[i]
    def jump_to(self,a):
        if a>len(self.code): self.runtime_error(f"Gecersiz jump adresi: {a}","NAX-R008")
        self.ip=a
    def run(self):
        while self.ip<len(self.code):
            ins=self.code[self.ip]; self.ip+=1
            if ins==OP_PUSH_CONST:
                i=self.read_u16()
                if i>=len(self.constants): self.runtime_error(f"Gecersiz constant index: {i}","NAX-R003")
                self.stack.append(self.constants[i])
            elif ins==OP_PUSH_NULL: self.stack.append(None)
            elif ins==OP_ADD:
                b=self.pop_stack(); a=self.pop_stack()
                if self.is_bool(a) or self.is_bool(b): self.runtime_error("Boolean degerlerle toplama yapilamaz.","NAX-R016")
                try: self.stack.append(a+b)
                except TypeError: self.runtime_error("Toplama islemi gecersiz.","NAX-R004")
            elif ins==OP_SUB:
                b=self.pop_stack(); a=self.pop_stack()
                if self.is_bool(a) or self.is_bool(b): self.runtime_error("Boolean degerlerle cikarma yapilamaz.","NAX-R017")
                try: self.stack.append(a-b)
                except TypeError: self.runtime_error("Cikarma islemi sadece sayilarla yapilabilir.","NAX-R005")
            elif ins in (OP_EQUAL,OP_NOT_EQUAL,OP_LESS,OP_GREATER,OP_LESS_EQUAL,OP_GREATER_EQUAL):
                b=self.pop_stack(); a=self.pop_stack()
                if ins in (OP_LESS,OP_GREATER,OP_LESS_EQUAL,OP_GREATER_EQUAL) and (self.is_bool(a) or self.is_bool(b)):
                    self.runtime_error("Boolean degerler < > <= >= ile karsilastirilamaz.","NAX-R018")
                try:
                    self.stack.append({OP_EQUAL:a==b,OP_NOT_EQUAL:a!=b,OP_LESS:a<b,OP_GREATER:a>b,OP_LESS_EQUAL:a<=b,OP_GREATER_EQUAL:a>=b}[ins])
                except TypeError: self.runtime_error("Karsilastirma gecersiz.","NAX-R006")
            elif ins==OP_SET_VAR:
                i=self.read_u16(); self.variables[i]=self.pop_stack()
            elif ins==OP_GET_VAR:
                i=self.read_u16()
                if i not in self.variables: self.runtime_error(f"Tanimlanmamis degisken: {i}","NAX-R007")
                self.stack.append(self.variables[i])
            elif ins==OP_SET_LOCAL: self.set_local(self.read_u16(),self.pop_stack())
            elif ins==OP_GET_LOCAL: self.stack.append(self.get_local(self.read_u16()))
            elif ins==OP_JUMP_IF_FALSE:
                a=self.read_u16(); c=self.require_bool(self.pop_stack())
                if not c: self.jump_to(a)
            elif ins==OP_JUMP_IF_TRUE:
                a=self.read_u16(); c=self.require_bool(self.pop_stack())
                if c: self.jump_to(a)
            elif ins==OP_JUMP:
                self.jump_to(self.read_u16())
            elif ins==OP_NOT:
                c=self.require_bool(self.pop_stack(),"NAX-R023"); self.stack.append(not c)
            elif ins==OP_DUP:
                if not self.stack: self.runtime_error("Stack underflow.","NAX-R002")
                self.stack.append(self.stack[-1])
            elif ins==OP_ASSERT_BOOL:
                if not self.stack: self.runtime_error("Stack underflow.","NAX-R002")
                self.require_bool(self.stack[-1],"NAX-R023")
            elif ins==OP_CHECK_COUNT:
                v=self.pop_stack()
                if not self.is_int(v): self.runtime_error("dongu sayaci tam sayi olmali.","NAX-R024")
                if v<0: self.runtime_error("dongu sayaci negatif olamaz.","NAX-R025")
                self.stack.append(v)
            elif ins==OP_NEW_LIST:
                n=self.read_u16()
                if len(self.stack)<n: self.runtime_error("Liste icin yeterli eleman yok.","NAX-R026")
                items=self.stack[-n:] if n else []
                if n: del self.stack[-n:]
                self.stack.append(items)
            elif ins==OP_LIST_GET:
                i=self.pop_stack(); lst=self.require_list(self.pop_stack()); i=self.require_index(i,len(lst)); self.stack.append(lst[i])
            elif ins==OP_LIST_SET:
                val=self.pop_stack(); i=self.pop_stack(); lst=self.require_list(self.pop_stack()); i=self.require_index(i,len(lst)); lst[i]=val
            elif ins==OP_LIST_LEN:
                v=self.pop_stack()
                if self.is_list(v) or isinstance(v,str): self.stack.append(len(v))
                else: self.runtime_error("uzunluk() liste veya metin ister.","NAX-R027")
            elif ins==OP_LIST_PUSH:
                val=self.pop_stack(); lst=self.require_list(self.pop_stack()); lst.append(val)
            elif ins==OP_LIST_DEL:
                i=self.pop_stack(); lst=self.require_list(self.pop_stack()); i=self.require_index(i,len(lst)); del lst[i]
            elif ins==OP_PRINT: print(self.format_value(self.pop_stack()))
            elif ins==OP_INPUT_INT:
                i=self.read_u16()
                try: v=int(input())
                except ValueError: self.runtime_error("int input icin sayi girilmesi gerekiyor.","NAX-R009")
                if self.current_locals is None: self.variables[i]=v
                else: self.current_locals[i]=v
            elif ins==OP_INPUT_STR:
                i=self.read_u16(); v=input()
                if self.current_locals is None: self.variables[i]=v
                else: self.current_locals[i]=v
            elif ins==OP_CALL:
                addr=self.read_u16(); argc=self.read_u16()
                if addr>=len(self.code): self.runtime_error(f"Gecersiz function adresi: {addr}","NAX-R013")
                if len(self.stack)<argc: self.runtime_error("Function call icin yeterli arguman yok.","NAX-R014")
                args=self.stack[-argc:] if argc else []
                if argc: del self.stack[-argc:]
                self.frames.append(CallFrame(self.ip,self.current_locals)); self.current_locals={i:v for i,v in enumerate(args)}; self.ip=addr
            elif ins==OP_RETURN:
                value=self.pop_stack()
                if not self.frames: self.runtime_error("Gecersiz return.","NAX-R015")
                frame=self.frames.pop(); self.current_locals=frame.locals; self.ip=frame.return_ip; self.stack.append(value)
            elif ins==OP_POP: self.pop_stack()
            elif ins==OP_HALT: break
            else: self.runtime_error(f"Bilinmeyen opcode: 0x{ins:02X}","NAX-R010")
