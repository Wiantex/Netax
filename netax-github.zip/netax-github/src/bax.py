import struct
MAGIC=b"NATX"
VERSION=3

def write_bax(filename,constants,code):
    with open(filename,"wb") as f:
        f.write(MAGIC); f.write(struct.pack(">H",VERSION)); f.write(struct.pack(">H",len(constants)))
        for v in constants:
            if isinstance(v,bool): f.write(b"B"); f.write(b"\x01" if v else b"\x00")
            elif isinstance(v,int): f.write(b"I"); f.write(struct.pack(">q",v))
            elif isinstance(v,str):
                d=v.encode("utf-8"); f.write(b"S"); f.write(struct.pack(">I",len(d))); f.write(d)
            elif v is None: f.write(b"N")
            else: raise TypeError(f"Desteklenmeyen sabit tipi: {type(v).__name__}")
        f.write(struct.pack(">I",len(code))); f.write(bytes(code))

def read_bax(filename):
    with open(filename,"rb") as f:
        if f.read(4)!=MAGIC: raise RuntimeError("Gecersiz .bax dosyasi.")
        vd=f.read(2)
        if len(vd)!=2: raise RuntimeError(".bax version bilgisi eksik.")
        v=struct.unpack(">H",vd)[0]
        if v!=VERSION: raise RuntimeError(f"Desteklenmeyen .bax surumu: {v}")
        cd=f.read(2)
        if len(cd)!=2: raise RuntimeError(".bax constant sayisi eksik.")
        n=struct.unpack(">H",cd)[0]; cs=[]
        for _ in range(n):
            t=f.read(1)
            if t==b"B":
                d=f.read(1)
                if len(d)!=1: raise RuntimeError(".bax boolean constant eksik.")
                if d not in (b"\x00", b"\x01"): raise RuntimeError(".bax boolean degeri gecersiz.")
                cs.append(d==b"\x01")
            elif t==b"I":
                d=f.read(8)
                if len(d)!=8: raise RuntimeError(".bax integer constant eksik.")
                cs.append(struct.unpack(">q",d)[0])
            elif t==b"S":
                d=f.read(4)
                if len(d)!=4: raise RuntimeError(".bax string uzunlugu eksik.")
                ln=struct.unpack(">I",d)[0]; data=f.read(ln)
                if len(data)!=ln: raise RuntimeError(".bax string verisi eksik.")
                cs.append(data.decode("utf-8"))
            elif t==b"N": cs.append(None)
            else: raise RuntimeError("Bilinmeyen constant tipi.")
        d=f.read(4)
        if len(d)!=4: raise RuntimeError(".bax code size eksik.")
        ln=struct.unpack(">I",d)[0]; code=f.read(ln)
        if len(code)!=ln: raise RuntimeError(".bax kod bolumu eksik.")
        return cs,list(code)
