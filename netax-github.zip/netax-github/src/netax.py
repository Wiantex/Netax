import sys,os,json
from lexer import Lexer
from parser import Parser
from compiler import Compiler
from vm import NetaxVM
from bax import write_bax,read_bax
from errors import NetaxError

ROOT=os.path.dirname(os.path.abspath(__file__))
CONFIG=os.path.join(ROOT,"Nebucon","config.json")

def auto_control_enabled():
    try:
        with open(CONFIG,encoding="utf-8") as f: return bool(json.load(f).get("automatic_control",False))
    except (OSError,ValueError): return False

def set_auto(value):
    os.makedirs(os.path.dirname(CONFIG),exist_ok=True)
    with open(CONFIG,"w",encoding="utf-8") as f: json.dump({"automatic_control":value},f,indent=2)

def compile_file(filename):
    if not filename.endswith(".ax"): raise RuntimeError("Kaynak dosya .ax olmali.")
    with open(filename,encoding="utf-8") as f: source=f.read()
    ast=Parser(Lexer(source).tokenize()).parse(); constants,code=Compiler().compile(ast)
    out=filename[:-3]+".bax"; write_bax(out,constants,code); print(f".bax olusturuldu: {out}")
    return out

def run_bax(filename):
    constants,code=read_bax(filename); vm=NetaxVM(); vm.load_program(constants,code); vm.run()

def auto_control(filename):
    from Nebucon.nebucon import control_file
    try:
        control_file(filename)
        print("[Nebucon] Automatic Control: PASS ✓")
    except Exception as e:
        print(f"[Nebucon] Automatic Control: FAIL ✗")
        raise RuntimeError(f"Nebucon kontrolu basarisiz: {e}")

def main():
    args=sys.argv[1:]
    if not args:
        print("Netax v0.3.3\n\nKullanim:\n  python netax.py dosya.ax\n  python netax.py dosya.bax\n  python netax.py -au nbcnau true\n  python netax.py -au nbcnau false\n  python netax.py -au nbcnau status"); return 1
    if args[:2]==["-au","nbcnau"]:
        if len(args)!=3 or args[2] not in ("true","false","status"):
            print("Hata: -au nbcnau true|false|status kullan."); return 1
        if args[2]=="true": set_auto(True); print("[Nebucon] Automatic Control: ENABLED ✓"); return 0
        if args[2]=="false": set_auto(False); print("[Nebucon] Automatic Control: DISABLED ✓"); return 0
        print(f"[Nebucon] Automatic Control: {'ENABLED ✓' if auto_control_enabled() else 'DISABLED ✗'}"); return 0
    if len(args)!=1: print("Hata: Tek dosya bekleniyor."); return 1
    filename=args[0]
    try:
        if filename.endswith(".ax"):
            bax=compile_file(filename)
            if auto_control_enabled(): auto_control(filename)
            run_bax(bax)
        elif filename.endswith(".bax"):
            run_bax(filename)
        else:
            print("Hata: Dosya .ax veya .bax olmali."); return 1
        return 0
    except NetaxError as e: print(f"Netax Hatasi: {e}"); return 1
    except (SyntaxError,RuntimeError,TypeError,ValueError,UnicodeError) as e: print(f"Netax Hatasi: {e}"); return 1
if __name__=="__main__": sys.exit(main())
