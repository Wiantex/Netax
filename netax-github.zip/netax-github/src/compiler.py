from netax_ast import *
from errors import NetaxCompileError
from opcodes import *

CMP_OPS={"==":OP_EQUAL,"!=":OP_NOT_EQUAL,"<":OP_LESS,">":OP_GREATER,"<=":OP_LESS_EQUAL,">=":OP_GREATER_EQUAL}
BUILTINS={"ekle","sil","uzunluk"}

class Compiler:
    def __init__(self):
        self.constants=[]; self.variables=[]; self.code=[]
        self.functions={}; self.function_addresses={}; self.function_patches=[]; self.current_function=None
        self.local_variables={}; self.loops=[]; self.loop_id=0
    def compile(self, program):
        funcs=[s for s in program.statements if isinstance(s,FunctionDeclaration)]
        for f in funcs:
            if f.name in self.functions: raise NetaxCompileError(f"Fonksiyon tekrar tanimlandi: {f.name}",error_type="Compile Error",code="NAX-C015")
            if f.name in BUILTINS: raise NetaxCompileError(f"Bu isim ayirildi: {f.name}",error_type="Compile Error",code="NAX-C015")
            if len(f.params)>0xFFFF: raise NetaxCompileError("Cok fazla fonksiyon parametresi.",error_type="Compile Error",code="NAX-C016")
            self.functions[f.name]=f
        for s in program.statements:
            if not isinstance(s,FunctionDeclaration): self.compile_statement(s)
        self.code.append(OP_HALT)
        for f in funcs: self.compile_function(f)
        for pos,name in self.function_patches:
            if name not in self.functions: raise NetaxCompileError(f"Bilinmeyen fonksiyon: {name}",error_type="Compile Error",code="NAX-C017")
            self.patch_u16(pos,self.function_addresses[name])
        return self.constants,self.code
    def add_constant(self,value):
        if value in self.constants: return self.constants.index(value)
        if len(self.constants)>0xFFFF: raise NetaxCompileError("Cok fazla sabit. Maksimum 65536 sabit destekleniyor.",error_type="Compile Error",code="NAX-C001")
        self.constants.append(value); return len(self.constants)-1
    def get_variable_index(self,name):
        if name not in self.variables:
            if len(self.variables)>0xFFFF: raise NetaxCompileError("Cok fazla degisken. Maksimum 65536 degisken destekleniyor.",error_type="Compile Error",code="NAX-C002")
            self.variables.append(name)
        return self.variables.index(name)
    def emit_u16(self,v):
        if not 0<=v<=0xFFFF: raise NetaxCompileError(f"16-bit deger aralik disi: {v}",error_type="Compile Error",code="NAX-C003")
        self.code += [(v>>8)&255,v&255]
    def patch_u16(self,pos,v):
        if not 0<=v<=0xFFFF: raise NetaxCompileError(f"Jump adresi aralik disi: {v}",error_type="Compile Error",code="NAX-C004")
        if pos<0 or pos+1>=len(self.code): raise NetaxCompileError(f"Gecersiz bytecode patch konumu: {pos}",error_type="Compile Error",code="NAX-C005")
        self.code[pos]=(v>>8)&255; self.code[pos+1]=v&255
    def emit_jump(self,op): self.code.append(op); p=len(self.code); self.emit_u16(0); return p
    def compile_statement(self,s):
        if isinstance(s,PrintStatement): self.compile_expression(s.expression); self.code.append(OP_PRINT); return
        if isinstance(s,VariableDeclaration): self.compile_expression(s.expression); self.emit_set(s.name); return
        if isinstance(s,AssignmentStatement):
            if s.index is None: self.compile_expression(s.expression); self.emit_set(s.name); return
            self.emit_get(s.name); self.compile_expression(s.index); self.compile_expression(s.expression); self.code.append(OP_LIST_SET); return
        if isinstance(s,InputStatement): self.compile_input(s); return
        if isinstance(s,IfStatement): self.compile_if(s); return
        if isinstance(s,WhileStatement): self.compile_while(s); return
        if isinstance(s,LoopStatement):
            kind="sonsuz" if s.mode=="normal" else "count"
            count=None if kind=="sonsuz" else NumberLiteral(s.count)
            self.compile_dongu(DonguStatement(kind,count,s.body)); return
        if isinstance(s,DonguStatement): self.compile_dongu(s); return
        if isinstance(s,BreakStatement):
            if not self.loops: raise NetaxCompileError("kir sadece dongu icinde kullanilir.",error_type="Compile Error",code="NAX-C025")
            self.loops[-1]["breaks"].append(self.emit_jump(OP_JUMP)); return
        if isinstance(s,ContinueStatement):
            if not self.loops: raise NetaxCompileError("devam sadece dongu icinde kullanilir.",error_type="Compile Error",code="NAX-C026")
            self.loops[-1]["continues"].append(self.emit_jump(OP_JUMP)); return
        if isinstance(s,ExpressionStatement): self.compile_expression(s.expression); self.code.append(OP_POP); return
        if isinstance(s,ReturnStatement):
            if self.current_function is None: raise NetaxCompileError("don sadece fonksiyon icinde kullanilabilir.",error_type="Compile Error",code="NAX-C018")
            if s.expression is None: self.code.append(OP_PUSH_NULL)
            else: self.compile_expression(s.expression)
            self.code.append(OP_RETURN); return
        if isinstance(s,FunctionDeclaration): raise NetaxCompileError("Ic ice fonksiyon tanimi desteklenmiyor.",error_type="Compile Error",code="NAX-C019")
        raise NetaxCompileError(f"Desteklenmeyen statement: {type(s).__name__}",error_type="Compile Error",code="NAX-C006")
    def emit_set(self,name):
        if self.current_function is not None:
            idx=self.local_variables.get(name)
            if idx is None:
                idx=len(self.local_variables); self.local_variables[name]=idx
            self.code.append(OP_SET_LOCAL); self.emit_u16(idx)
        else:
            idx=self.get_variable_index(name); self.code.append(OP_SET_VAR); self.emit_u16(idx)
    def emit_get(self,name):
        if self.current_function is not None and name in self.local_variables:
            self.code.append(OP_GET_LOCAL); self.emit_u16(self.local_variables[name]); return
        if name in self.variables:
            self.code.append(OP_GET_VAR); self.emit_u16(self.variables.index(name)); return
        raise NetaxCompileError(f"Tanimlanmamis degisken: {name}",error_type="Compile Error",code="NAX-C020")
    def compile_if(self,s):
        ends=[]; self.compile_expression(s.condition); fj=self.emit_jump(OP_JUMP_IF_FALSE)
        for x in s.body: self.compile_statement(x)
        if s.else_if_branches or s.else_body: ends.append(self.emit_jump(OP_JUMP))
        self.patch_u16(fj,len(self.code))
        for i,b in enumerate(s.else_if_branches):
            self.compile_expression(b.condition); fj=self.emit_jump(OP_JUMP_IF_FALSE)
            for x in b.body: self.compile_statement(x)
            if i<len(s.else_if_branches)-1 or s.else_body: ends.append(self.emit_jump(OP_JUMP))
            self.patch_u16(fj,len(self.code))
        for x in s.else_body: self.compile_statement(x)
        for p in ends: self.patch_u16(p,len(self.code))
    def compile_while(self,s):
        start=len(self.code)
        info={"continues":[],"breaks":[]}
        self.loops.append(info)
        self.compile_expression(s.condition); fj=self.emit_jump(OP_JUMP_IF_FALSE)
        for x in s.body: self.compile_statement(x)
        self.code.append(OP_JUMP); self.emit_u16(start)
        end=len(self.code); self.patch_u16(fj,end)
        for p in info["breaks"]: self.patch_u16(p,end)
        for p in info["continues"]: self.patch_u16(p,start)
        self.loops.pop()
    def compile_dongu(self,s):
        if s.kind=="sonsuz":
            start=len(self.code)
            info={"continues":[],"breaks":[]}
            self.loops.append(info)
            for x in s.body: self.compile_statement(x)
            for p in info["continues"]: self.patch_u16(p,start)
            self.code.append(OP_JUMP); self.emit_u16(start)
            end=len(self.code)
            for p in info["breaks"]: self.patch_u16(p,end)
            self.loops.pop(); return
        self.loop_id+=1; hidden=f"$n{self.loop_id}"
        self.compile_expression(s.count); self.code.append(OP_CHECK_COUNT); self.emit_set(hidden)
        start=len(self.code)
        info={"continues":[],"breaks":[]}
        self.loops.append(info)
        self.emit_get(hidden)
        self.code.append(OP_PUSH_CONST); self.emit_u16(self.add_constant(0))
        self.code.append(OP_GREATER)
        fj=self.emit_jump(OP_JUMP_IF_FALSE)
        for x in s.body: self.compile_statement(x)
        cont=len(self.code)
        for p in info["continues"]: self.patch_u16(p,cont)
        self.emit_get(hidden)
        self.code.append(OP_PUSH_CONST); self.emit_u16(self.add_constant(1))
        self.code.append(OP_SUB); self.emit_set(hidden)
        self.code.append(OP_JUMP); self.emit_u16(start)
        end=len(self.code); self.patch_u16(fj,end)
        for p in info["breaks"]: self.patch_u16(p,end)
        for p in info["continues"]: self.patch_u16(p,start)
        self.loops.pop()
    def compile_input(self,s):
        inputs=self.find_inputs(s.prompt)
        if not inputs: raise NetaxCompileError("Giris() icinde f(degisken, tip) bulunamadi.",error_type="Compile Error",code="NAX-C009")
        if len(inputs)>1: raise NetaxCompileError("Giris() icinde birden fazla input kullanilamaz.",error_type="Compile Error",code="NAX-C010")
        inp=inputs[0]; parts=self.flatten_add(s.prompt); static=[p for p in parts if not isinstance(p,InputExpression)]
        if static:
            self.compile_expression(static[0])
            for p in static[1:]: self.compile_expression(p); self.code.append(OP_ADD)
            self.code.append(OP_PRINT)
        if inp.value_type not in ("int","str"): raise NetaxCompileError(f"Bilinmeyen input tipi: {inp.value_type}",error_type="Compile Error",code="NAX-C011")
        if self.current_function is not None:
            idx=self.local_variables.get(inp.variable)
            if idx is None: idx=len(self.local_variables); self.local_variables[inp.variable]=idx
            self.code.append(OP_INPUT_INT if inp.value_type=="int" else OP_INPUT_STR); self.emit_u16(idx)
        else:
            idx=self.get_variable_index(inp.variable); self.code.append(OP_INPUT_INT if inp.value_type=="int" else OP_INPUT_STR); self.emit_u16(idx)
    def find_inputs(self,e):
        if isinstance(e,InputExpression): return [e]
        if isinstance(e,BinaryExpression): return self.find_inputs(e.left)+self.find_inputs(e.right)
        if isinstance(e,UnaryExpression): return self.find_inputs(e.operand)
        return []
    def flatten_add(self,e):
        if isinstance(e,BinaryExpression) and e.operator=="+": return self.flatten_add(e.left)+self.flatten_add(e.right)
        return [e]
    def compile_expression(self,e):
        if isinstance(e,(NumberLiteral,StringLiteral,BooleanLiteral)): self.code.append(OP_PUSH_CONST); self.emit_u16(self.add_constant(e.value)); return
        if isinstance(e,Identifier): self.emit_get(e.name); return
        if isinstance(e,UnaryExpression):
            if e.operator!="degil": raise NetaxCompileError(f"Bilinmeyen tekli operator: {e.operator}",error_type="Compile Error",code="NAX-C021")
            self.compile_expression(e.operand); self.code.append(OP_NOT); return
        if isinstance(e,BinaryExpression):
            if e.operator=="ve":
                self.compile_expression(e.left); self.code.append(OP_DUP); jf=self.emit_jump(OP_JUMP_IF_FALSE)
                self.code.append(OP_POP); self.compile_expression(e.right); self.code.append(OP_ASSERT_BOOL)
                self.patch_u16(jf,len(self.code)); return
            if e.operator=="veya":
                self.compile_expression(e.left); self.code.append(OP_DUP); jt=self.emit_jump(OP_JUMP_IF_TRUE)
                self.code.append(OP_POP); self.compile_expression(e.right); self.code.append(OP_ASSERT_BOOL)
                self.patch_u16(jt,len(self.code)); return
            if e.operator in CMP_OPS:
                self.compile_expression(e.left); self.compile_expression(e.right); self.code.append(CMP_OPS[e.operator]); return
            self.compile_expression(e.left); self.compile_expression(e.right)
            if e.operator=="+": self.code.append(OP_ADD)
            elif e.operator=="-": self.code.append(OP_SUB)
            else: raise NetaxCompileError(f"Ifade operatoru desteklenmiyor: {e.operator}",error_type="Compile Error",code="NAX-C021")
            return
        if isinstance(e,ListLiteral):
            for x in e.elements: self.compile_expression(x)
            self.code.append(OP_NEW_LIST); self.emit_u16(len(e.elements)); return
        if isinstance(e,IndexExpression):
            self.compile_expression(e.target); self.compile_expression(e.index); self.code.append(OP_LIST_GET); return
        if isinstance(e,InputExpression): raise NetaxCompileError("f(degisken, tip) sadece Giris() icinde kullanilabilir.",error_type="Compile Error",code="NAX-C022")
        if isinstance(e,FunctionCall):
            if e.name=="uzunluk":
                if len(e.arguments)!=1: raise NetaxCompileError("uzunluk() 1 arguman ister.",error_type="Compile Error",code="NAX-C023")
                self.compile_expression(e.arguments[0]); self.code.append(OP_LIST_LEN); return
            if e.name=="ekle":
                if len(e.arguments)!=2: raise NetaxCompileError("ekle() 2 arguman ister.",error_type="Compile Error",code="NAX-C023")
                self.compile_expression(e.arguments[0]); self.compile_expression(e.arguments[1]); self.code.append(OP_LIST_PUSH); self.code.append(OP_PUSH_NULL); return
            if e.name=="sil":
                if len(e.arguments)!=2: raise NetaxCompileError("sil() 2 arguman ister.",error_type="Compile Error",code="NAX-C023")
                self.compile_expression(e.arguments[0]); self.compile_expression(e.arguments[1]); self.code.append(OP_LIST_DEL); self.code.append(OP_PUSH_NULL); return
            if e.name not in self.functions: raise NetaxCompileError(f"Bilinmeyen fonksiyon: {e.name}",error_type="Compile Error",code="NAX-C017")
            expected=len(self.functions[e.name].params)
            if len(e.arguments)!=expected: raise NetaxCompileError(f"{e.name}() {expected} parametre bekliyor, {len(e.arguments)} verildi.",error_type="Compile Error",code="NAX-C023")
            for a in e.arguments: self.compile_expression(a)
            self.code.append(OP_CALL); p=len(self.code); self.emit_u16(0); self.function_patches.append((p,e.name)); self.emit_u16(len(e.arguments)); return
        raise NetaxCompileError(f"Desteklenmeyen ifade: {type(e).__name__}",error_type="Compile Error",code="NAX-C024")
    def collect_local_names(self, stmts):
        names=[]
        def walk(xs):
            for s in xs:
                if isinstance(s,(VariableDeclaration,AssignmentStatement,InputStatement)):
                    n = s.name if hasattr(s, "name") else s.variable
                    if n not in names: names.append(n)
                if isinstance(s,IfStatement):
                    walk(s.body)
                    for br in s.else_if_branches: walk(br.body)
                    walk(s.else_body)
                elif isinstance(s,(WhileStatement,LoopStatement,DonguStatement)):
                    walk(s.body)
        walk(stmts)
        return names
    def compile_function(self,f):
        self.function_addresses[f.name]=len(self.code)
        old=self.current_function; oldlocals=self.local_variables
        self.current_function=f; self.local_variables={}
        for p in f.params: self.local_variables[p]=len(self.local_variables)
        for n in self.collect_local_names(f.body):
            if n not in self.local_variables: self.local_variables[n]=len(self.local_variables)
        for st in f.body: self.compile_statement(st)
        self.code.append(OP_PUSH_NULL); self.code.append(OP_RETURN)
        self.current_function=old; self.local_variables=oldlocals
