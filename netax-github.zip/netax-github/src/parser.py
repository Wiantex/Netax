from netax_ast import (Program, PrintStatement, InputStatement, VariableDeclaration, AssignmentStatement, IfStatement, ElseIfBranch, WhileStatement, LoopStatement, DonguStatement, BreakStatement, ContinueStatement, FunctionDeclaration, FunctionCall, ExpressionStatement, ReturnStatement, NumberLiteral, BooleanLiteral, StringLiteral, Identifier, BinaryExpression, UnaryExpression, ListLiteral, IndexExpression, InputExpression)
from errors import NetaxSyntaxError
from lexer import norm_ident

CMP={"EQUAL_EQUAL","NOT_EQUAL","LESS","GREATER","LESS_EQUAL","GREATER_EQUAL"}

class Parser:
    def __init__(self,tokens): self.tokens=tokens; self.position=0
    def current(self): return self.tokens[self.position]
    def advance(self): t=self.current(); self.position+=1; return t
    def expect(self,typ):
        t=self.current()
        if t.type!=typ: raise NetaxSyntaxError(f"Beklenen token: {typ}, bulunan: {t.type}",t.line,t.column,"NAX-E006")
        return self.advance()
    def parse(self):
        out=[]
        while self.current().type!="EOF":
            s=self.parse_statement()
            out.extend(s if isinstance(s,list) else [s])
        return Program(out)
    def parse_statement(self):
        t=self.current().type
        if t=="YAZDIR": return self.parse_print()
        if t=="GIRIS": return self.parse_input()
        if t=="VAR": return self.parse_var()
        if t=="F": return self.parse_assignment()
        if t=="LISTE": return self.parse_liste_assign()
        if t=="EGER": return self.parse_if()
        if t=="IKEN": return self.parse_while()
        if t=="FONKSIYON": return self.parse_function()
        if t=="LOOP": return self.parse_loop()
        if t=="DONGU": return self.parse_dongu()
        if t=="KIR": self.advance(); self.optional_semicolon(); return BreakStatement()
        if t=="DEVAM": self.advance(); self.optional_semicolon(); return ContinueStatement()
        if t=="DON": return self.parse_return()
        if t in ("EKLE","SIL","UZUNLUK") or (t=="IDENTIFIER" and self.position+1<len(self.tokens) and self.tokens[self.position+1].type=="LPAREN"):
            e=self.parse_expression(); self.optional_semicolon(); return ExpressionStatement(e)
        tok=self.current(); raise NetaxSyntaxError(f"Beklenmeyen token: {tok.value!r}",tok.line,tok.column,"NAX-E005")
    def optional_semicolon(self):
        if self.current().type=="SEMICOLON": self.advance()
    def parse_print(self):
        self.expect("YAZDIR"); self.expect("LPAREN"); e=self.parse_expression(); self.expect("RPAREN"); self.optional_semicolon(); return PrintStatement(e)
    def parse_input(self):
        self.expect("GIRIS"); self.expect("LPAREN"); prompt=self.parse_expression(); self.expect("RPAREN"); self.optional_semicolon()
        inp=self.find_input_expression(prompt)
        if inp is None:
            t=self.current(); raise NetaxSyntaxError("Giris() icinde f(degisken, tip) kullanilmali.",t.line,t.column,"NAX-E011")
        return InputStatement(prompt,inp.variable,inp.value_type)
    def parse_binding(self, keyword):
        self.expect(keyword); self.expect("LPAREN"); name=self.expect("IDENTIFIER").value
        index=None
        if self.current().type=="LBRACKET":
            self.advance(); index=self.parse_expression(); self.expect("RBRACKET")
        self.expect("EQUAL"); e=self.parse_expression(); self.expect("RPAREN"); self.optional_semicolon()
        if index is None:
            return VariableDeclaration(name,e) if keyword=="LISTE" else AssignmentStatement(name,e)
        if keyword=="LISTE":
            t=self.current(); raise NetaxSyntaxError("liste() ile indeks atamasi yapilamaz.",t.line,t.column,"NAX-E015")
        return AssignmentStatement(name,e,index)
    def parse_assignment(self):
        node=self.parse_binding("F")
        if isinstance(node,AssignmentStatement): return node
        return AssignmentStatement(node.name,node.expression)
    def parse_liste_assign(self):
        self.expect("LISTE"); self.expect("LPAREN"); name=self.expect("IDENTIFIER").value
        self.expect("EQUAL"); e=self.parse_expression(); self.expect("RPAREN"); self.optional_semicolon()
        return AssignmentStatement(name,e)
    def parse_var(self):
        self.expect("VAR"); self.expect("LBRACE"); ds=[]
        while self.current().type!="RBRACE":
            if self.current().type=="EOF":
                t=self.current(); raise NetaxSyntaxError("var blogu kapatilmamis.",t.line,t.column,"NAX-E007")
            if self.current().type=="LISTE":
                self.advance(); self.expect("LPAREN"); name=self.expect("IDENTIFIER").value
                self.expect("EQUAL"); e=self.parse_expression(); self.expect("RPAREN"); self.optional_semicolon()
                ds.append(VariableDeclaration(name,e)); continue
            self.expect("F"); self.expect("LPAREN"); name=self.expect("IDENTIFIER").value
            if self.current().type=="LBRACKET":
                t=self.current(); raise NetaxSyntaxError("var icinde indeks atamasi yok, once listeyi tanimla.",t.line,t.column,"NAX-E015")
            self.expect("EQUAL"); e=self.parse_expression(); self.expect("RPAREN"); self.optional_semicolon()
            ds.append(VariableDeclaration(name,e))
        self.expect("RBRACE"); return ds
    def parse_if(self):
        self.expect("EGER"); cond=self.parse_expression(); self.expect("LBRACE"); body=self.parse_block(); eis=[]; eb=[]
        while self.current().type=="DEGILSE":
            self.advance()
            if self.current().type=="EGER":
                self.advance(); c=self.parse_expression(); self.expect("LBRACE"); eis.append(ElseIfBranch(c,self.parse_block()))
            else:
                self.expect("LBRACE"); eb=self.parse_block(); break
        return IfStatement(cond,body,eis,eb)
    def parse_while(self):
        self.expect("IKEN"); c=self.parse_expression(); self.expect("LBRACE"); return WhileStatement(c,self.parse_block())
    def parse_loop(self):
        self.expect("LOOP"); self.expect("LBRACE"); t=self.current()
        if t.type=="NORMAL":
            self.advance(); self.expect("RBRACE"); self.expect("LBRACE")
            return DonguStatement("sonsuz",None,self.parse_block())
        if t.type=="IDENTIFIER" and isinstance(t.value,str) and norm_ident(t.value).startswith("tkr") and norm_ident(t.value)[3:].isdigit():
            n=int(t.value[3:]); self.advance(); self.expect("RBRACE"); self.expect("LBRACE")
            return DonguStatement("count",NumberLiteral(n),self.parse_block())
        raise NetaxSyntaxError("loop icinde normal veya tkrN kullanilmali.",t.line,t.column,"NAX-E013")
    def parse_dongu(self):
        self.expect("DONGU"); self.expect("LPAREN")
        if self.current().type=="SONSUZ":
            self.advance(); kind="sonsuz"; count=None
        else:
            kind="count"; count=self.parse_expression()
        self.expect("RPAREN"); self.expect("LBRACE")
        return DonguStatement(kind,count,self.parse_block())
    def parse_function(self):
        self.expect("FONKSIYON"); self.expect("LPAREN")
        n=self.expect("IDENTIFIER")
        if norm_ident(n.value)!="n": raise NetaxSyntaxError("Fonksiyon taniminda n=isim kullanilmali.",n.line,n.column,"NAX-E014")
        self.expect("EQUAL"); name=self.expect("IDENTIFIER").value; params=[]
        if self.current().type=="COMMA":
            self.advance()
            while True:
                params.append(self.expect("IDENTIFIER").value)
                if self.current().type!="COMMA": break
                self.advance()
        self.expect("RPAREN"); self.expect("LBRACE"); return FunctionDeclaration(name,params,self.parse_block())
    def parse_return(self):
        self.expect("DON")
        if self.current().type in ("RBRACE","EOF","SEMICOLON"):
            self.optional_semicolon(); return ReturnStatement()
        e=self.parse_expression(); self.optional_semicolon(); return ReturnStatement(e)
    def parse_block(self):
        out=[]
        while self.current().type!="RBRACE":
            if self.current().type=="EOF":
                t=self.current(); raise NetaxSyntaxError("Kapatilmamis blok.",t.line,t.column,"NAX-E008")
            s=self.parse_statement(); out.extend(s if isinstance(s,list) else [s])
        self.expect("RBRACE"); return out
    def parse_expression(self):
        return self.parse_or()
    def parse_or(self):
        l=self.parse_and()
        while self.current().type=="VEYA":
            self.advance(); r=self.parse_and(); l=BinaryExpression(l,"veya",r)
        return l
    def parse_and(self):
        l=self.parse_not()
        while self.current().type=="VE":
            self.advance(); r=self.parse_not(); l=BinaryExpression(l,"ve",r)
        return l
    def parse_not(self):
        if self.current().type=="DEGIL":
            self.advance(); return UnaryExpression("degil",self.parse_not())
        return self.parse_comparison()
    def parse_comparison(self):
        l=self.parse_add()
        if self.current().type not in CMP: return l
        op=self.advance(); r=self.parse_add()
        if self.current().type in CMP:
            t=self.current(); raise NetaxSyntaxError("Zincir karsilastirma yok. Parantez kullan.",t.line,t.column,"NAX-E009")
        return BinaryExpression(l,op.value,r)
    def parse_add(self):
        l=self.parse_postfix()
        while self.current().type in ("PLUS","MINUS"):
            op=self.advance(); r=self.parse_postfix(); l=BinaryExpression(l,op.value,r)
        return l
    def parse_postfix(self):
        e=self.parse_primary()
        while self.current().type=="LBRACKET":
            self.advance(); idx=self.parse_expression(); self.expect("RBRACKET"); e=IndexExpression(e,idx)
        return e
    def parse_primary(self):
        t=self.current()
        if t.type=="NUMBER": self.advance(); return NumberLiteral(t.value)
        if t.type=="DOGRU": self.advance(); return BooleanLiteral(True)
        if t.type=="YANLIS": self.advance(); return BooleanLiteral(False)
        if t.type=="STRING": self.advance(); return StringLiteral(t.value)
        if t.type=="LBRACKET": return self.parse_list_literal()
        if t.type=="F": return self.parse_input_expression()
        if t.type in ("EKLE","SIL","UZUNLUK"):
            name=self.advance().value; return self.parse_call_after_name(name)
        if t.type=="IDENTIFIER":
            self.advance()
            if self.current().type=="LPAREN":
                return self.parse_call_after_name(t.value)
            return Identifier(t.value)
        if t.type=="LPAREN": self.advance(); e=self.parse_expression(); self.expect("RPAREN"); return e
        raise NetaxSyntaxError(f"Beklenmeyen ifade: {t.value!r}",t.line,t.column,"NAX-E012")
    def parse_list_literal(self):
        self.expect("LBRACKET"); elems=[]
        if self.current().type!="RBRACKET":
            while True:
                elems.append(self.parse_expression())
                if self.current().type!="COMMA": break
                self.advance()
        self.expect("RBRACKET"); return ListLiteral(elems)
    def parse_call_after_name(self,name):
        self.expect("LPAREN"); args=[]
        if self.current().type!="RPAREN":
            while True:
                args.append(self.parse_expression())
                if self.current().type!="COMMA": break
                self.advance()
        self.expect("RPAREN"); return FunctionCall(name,args)
    def parse_input_expression(self):
        self.expect("F"); self.expect("LPAREN"); v=self.expect("IDENTIFIER").value; self.expect("COMMA"); typ=self.expect("IDENTIFIER")
        if norm_ident(typ.value) not in ("int","str"): raise NetaxSyntaxError(f"Gecersiz input tipi: {typ.value}",typ.line,typ.column,"NAX-E010")
        self.expect("RPAREN"); return InputExpression(v,norm_ident(typ.value))
    def find_input_expression(self,e):
        if isinstance(e,InputExpression): return e
        if isinstance(e,BinaryExpression): return self.find_input_expression(e.left) or self.find_input_expression(e.right)
        if isinstance(e,UnaryExpression): return self.find_input_expression(e.operand)
        return None
