# Netax

Netax, `.ax` kaynağını `.bax` ara biçimine derleyip yığın tabanlı bir sanal makinede çalıştıran bir programlama dilidir.

Şu anki sürüm: **v0.3.3**

## Durum

Çalışır: `yazdir`, `var` / `f()`, `eger`, `iken`, `dongu`, `kir`, `devam`, `fonksiyon`, `dogru` / `yanlis`, `ve` / `veya` / `degil`, liste, `ekle` / `sil` / `uzunluk`, `Giris`

Keyword'ler büyük/küçük harf duyarsızdır (`Giris`, `giris`, `GiRis`).

Henüz yok: C çekirdek, paket sistemi, standart kütüphane. Plan için `ROADMAP.md`.

## Çalıştırma

```bash
python3 src/netax.py examples/merhaba.ax
```

## Klasörler

| Klasör | İçerik |
|---|---|
| `src/` | Python toolchain |
| `examples/` | Örnek `.ax` |
| `docs/` | Dil ve bytecode notları |
| `tests/` | Regression |
| `tools/nebucon/` | Otomatik kontrol |

## Lisans

Anteax Open Source License — `LICENSE`
