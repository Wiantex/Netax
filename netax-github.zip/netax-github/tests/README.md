Regression testleri.

Örnek: `python3 tests/run_031.py`
