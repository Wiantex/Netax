import io
import os
import sys
import contextlib
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from lexer import Lexer
from parser import Parser
from compiler import Compiler
from vm import NetaxVM
from bax import write_bax, read_bax
from errors import NetaxError


def run_source(source):
    ast = Parser(Lexer(source).tokenize()).parse()
    constants, code = Compiler().compile(ast)
    vm = NetaxVM()
    vm.load_program(constants, code)
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        vm.run()
    return buf.getvalue()


class Boolean031Tests(unittest.TestCase):
    def test_print_literals(self):
        out = run_source('yazdir(dogru)\nyazdir(yanlis)\n')
        self.assertEqual(out, "dogru\nyanlis\n")

    def test_if_variable(self):
        src = """
        var { f(aktif = dogru) }
        eger aktif { yazdir("Aktif") }
        """
        self.assertEqual(run_source(src), "Aktif\n")

    def test_else_false(self):
        src = """
        var { f(kapali = yanlis) }
        eger kapali { yazdir("A") } degilse { yazdir("B") }
        """
        self.assertEqual(run_source(src), "B\n")

    def test_comparison_still_works(self):
        src = """
        var { f(yas = 20) }
        eger yas >= 18 { yazdir("yetiskin") }
        """
        self.assertEqual(run_source(src), "yetiskin\n")

    def test_bool_equality(self):
        src = """
        eger dogru == dogru { yazdir("esit") }
        eger dogru != yanlis { yazdir("farkli") }
        """
        self.assertEqual(run_source(src), "esit\nfarkli\n")

    def test_non_bool_condition_fails(self):
        with self.assertRaises(NetaxError):
            run_source("eger 1 { yazdir(\"x\") }")

    def test_bool_add_fails(self):
        with self.assertRaises(NetaxError):
            run_source("yazdir(dogru + 1)")

    def test_bax_roundtrip(self):
        ast = Parser(Lexer("yazdir(dogru)").tokenize()).parse()
        constants, code = Compiler().compile(ast)
        path = os.path.join(os.path.dirname(__file__), "_tmp_bool.bax")
        write_bax(path, constants, code)
        cs, cd = read_bax(path)
        self.assertIn(True, cs)
        vm = NetaxVM()
        vm.load_program(cs, cd)
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            vm.run()
        self.assertEqual(buf.getvalue(), "dogru\n")
        os.remove(path)

    def test_function_return_bool_branch(self):
        src = """
        fonksiyon(n=etiket, durum) {
            eger durum { don "acik" } degilse { don "kapali" }
        }
        yazdir(etiket(dogru))
        yazdir(etiket(yanlis))
        """
        self.assertEqual(run_source(src), "acik\nkapali\n")


if __name__ == "__main__":
    unittest.main()
