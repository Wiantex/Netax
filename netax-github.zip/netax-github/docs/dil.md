# Netax dil notu (v0.3.3)

Keyword'ler büyük/küçük harf duyarsızdır.

- Cikti: `yazdir(ifade)`
- Degisken: `var { f(x = 1) }` ve `f(x = x + 1)`
- Kosul: `eger` / `degilse eger` / `degilse`
- Dongu: `iken`, `dongu(n)`, `dongu(sonsuz)`, `kir`, `devam`
- Fonksiyon: `fonksiyon(n=isim, a, b) { don ... }`
- Boolean: `dogru`, `yanlis`, `ve`, `veya`, `degil`
- Liste: `liste(ad = [1, 2])`, `ad[0]`, `ekle`, `sil`, `uzunluk`
- Girdi: `Giris("metin" + f(x, int))`
- Yorum: `# ...` ve `""" cok satirli """`
