# .bax

Sihir: `NATX`  
Sonra: surum, sabit havuzu, kod.

Sabit turleri: `I` int, `S` string, `B` boolean, `N` null.

Calistirici: `python3 src/netax.py dosya.bax`
