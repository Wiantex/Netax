import os,sys,io,random,string,builtins,contextlib

VERSION="0.1.1"
BASE_DIR=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
NEBUCON_DIR=os.path.dirname(os.path.abspath(__file__))
LIST_FILE=os.path.join(NEBUCON_DIR,"bl.ax")
CONFIG_FILE=os.path.join(NEBUCON_DIR,"config.json")
sys.path.insert(0,BASE_DIR)
from lexer import Lexer
from parser import Parser
from compiler import Compiler
from vm import NetaxVM

def load_list():
    if not os.path.exists(LIST_FILE): raise RuntimeError("Nebucon/bl.ax dosyasi bulunamadi.")
    with open(LIST_FILE,encoding="utf-8") as f: return [x.strip() for x in f if x.strip() and not x.strip().startswith("#")]

def resolve_path(path): return path if os.path.isabs(path) else os.path.join(BASE_DIR,path)
def random_text(): return "".join(random.choice(string.ascii_letters) for _ in range(random.randint(1,6)))

def find_input_types(node):
    out=[]; seen=set()
    def walk(x):
        if x is None or isinstance(x,(str,int,bool)): return
        if isinstance(x,list):
            for y in x: walk(y)
            return
        oid=id(x)
        if oid in seen: return
        seen.add(oid)
        if x.__class__.__name__=="InputExpression": out.append(x.value_type); return
        if hasattr(x,"__dict__"):
            for v in x.__dict__.values(): walk(v)
    walk(node); return out

def generate_input(t):
    if t=="int": return str(random.randint(1,9))
    if t=="str": return "Nebucon"
    return random_text()

def run_program(filename, verbose=True):
    with open(filename,encoding="utf-8") as f: source=f.read()
    ast=Parser(Lexer(source).tokenize()).parse()
    input_types=find_input_types(ast); pos=0
    def fake_input(prompt=""):
        nonlocal pos
        if pos<len(input_types): v=generate_input(input_types[pos]); pos+=1; return v
        return random_text()
    constants,code=Compiler().compile(ast)
    vm=NetaxVM(); vm.load_program(constants,code)
    old=builtins.input; builtins.input=fake_input
    buf=io.StringIO()
    try:
        with contextlib.redirect_stdout(buf): vm.run()
    finally: builtins.input=old
    return buf.getvalue()

def control_file(filename):
    result=run_program(filename)
    if result.strip() and False: pass
    return result

def main():
    targets = sys.argv[1:]
    if targets:
        total=len(targets); passed=0
        print("="*45); print(f"NEBUCON v{VERSION} - Automatic Control"); print("="*45)
        for rel in targets:
            path=resolve_path(rel)
            print(f"[CONTROL] {rel}")
            try:
                run_program(path)
                print("     PASS")
                passed+=1
            except Exception as e:
                print("     FAIL")
                print(f"     Hata: {e}")
        print(f"\n{passed}/{total} PROGRAM PASSED")
        return 0 if passed==total else 1
    files=load_list()
    if not files:
        print(f"Nebucon v{VERSION}: bl.ax kontrol listesi bos.")
        return 0
    total=len(files); passed=0
    print("="*45); print(f"NEBUCON v{VERSION} - Netax Bug Control"); print("="*45); print()
    for rel in files:
        path=resolve_path(rel); print(f"[TEST] {rel}")
        try:
            result=run_program(path)
            print("     PASS")
            if result.strip():
                print("     Cikti:")
                for line in result.splitlines(): print(f"       {line}")
            passed+=1
        except Exception as e:
            print("     FAIL"); print(f"     Hata: {e}")
    print(); print("="*45); print(f"{passed}/{total} PROGRAM PASSED"); print("="*45)
    print("NEBUCON: ALL PROGRAMS HEALTHY" if passed==total else "NEBUCON: SOME PROGRAMS FAILED")
    return 0 if passed==total else 1

if __name__=="__main__": sys.exit(main())
