Nebucon: örnek `.ax` dosyalarını otomatik çalıştırıp geçti/kaldı bakar.
